
let x = 3
let y = 4
let c = x + y
let d = c - 3;
console.log(d);
