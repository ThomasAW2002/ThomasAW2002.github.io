let tall1 = Number(prompt("Skriv inn fahrenheit"))

alert("Det er " + Math.floor((tall1 - 32) /1.8)+(" Celcius"))
